import { useEffect, useState } from 'react';
import { supabase } from '@/services/supabase';
import { useAuth } from '@/hooks/useAuth';
import type { Comment } from '@/types';

interface Props {
  chatId: string;
}

export function CommentsList({ chatId }: Props) {
  const { employee } = useAuth();
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(true);
  const [text, setText] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchComments();
  }, [chatId]);

  async function fetchComments() {
    setLoading(true);
    const { data, error } = await supabase
      .from('comments')
      .select('*, employee:employees(id, name)')
      .eq('chat_id', chatId)
      .order('created_at', { ascending: false });
    if (!error) setComments(data ?? []);
    setLoading(false);
  }

  async function addComment() {
    if (!employee || !text.trim()) return;
    setSaving(true);
    try {
      const { error } = await supabase.from('comments').insert({
        chat_id: chatId,
        employee_id: employee.id,
        text: text.trim(),
      });
      if (error) throw error;
      setText('');
      await fetchComments();
    } catch (err) {
      console.error('Comment create error:', err);
    } finally {
      setSaving(false);
    }
  }

  async function deleteComment(id: string) {
    await supabase.from('comments').delete().eq('id', id);
    setComments(prev => prev.filter(c => c.id !== id));
  }

  function formatDate(iso: string) {
    return new Date(iso).toLocaleDateString('ru-RU', {
      day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit',
    });
  }

  return (
    <div className="p-4 border-b border-gray-100">
      <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-3">
        Заметки {comments.length > 0 && <span className="ml-1 text-gray-400">{comments.length}</span>}
      </p>

      {/* Форма добавления */}
      <div className="mb-3 flex gap-2">
        <textarea
          rows={2}
          placeholder="Добавить заметку..."
          value={text}
          onChange={e => setText(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter' && e.metaKey) addComment(); }}
          className="flex-1 text-sm border border-gray-200 rounded px-2 py-1.5 resize-none focus:outline-none focus:ring-1 focus:ring-blue-400"
        />
        <button
          onClick={addComment}
          disabled={saving || !text.trim()}
          className="px-2 py-1 text-xs bg-gray-800 text-white rounded hover:bg-gray-700 disabled:opacity-40 transition-colors self-end"
        >
          {saving ? '...' : '↑'}
        </button>
      </div>

      {loading ? (
        <p className="text-xs text-gray-400">Загрузка...</p>
      ) : comments.length === 0 ? (
        <p className="text-xs text-gray-400">Нет заметок</p>
      ) : (
        <ul className="space-y-2.5">
          {comments.map(c => (
            <li key={c.id} className="group bg-yellow-50 rounded-lg px-3 py-2 relative">
              <p className="text-sm text-gray-800 whitespace-pre-wrap leading-snug">{c.text}</p>
              <div className="flex items-center justify-between mt-1.5">
                <span className="text-[10px] text-gray-400">
                  {(c.employee as any)?.name ?? 'Неизвестно'} · {formatDate(c.created_at)}
                </span>
                {employee && c.employee_id === employee.id && (
                  <button
                    onClick={() => deleteComment(c.id)}
                    className="opacity-0 group-hover:opacity-100 text-gray-300 hover:text-red-400 text-xs transition-all"
                  >
                    ✕
                  </button>
                )}
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

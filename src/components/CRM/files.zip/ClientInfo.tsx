import { useState } from 'react';
import { supabase } from '@/services/supabase';
import type { Client } from '@/types';

interface Props {
  client: Client;
  onUpdate?: (updated: Partial<Client>) => void;
}

const STATUS_LABELS: Record<Client['status'], string> = {
  new:         'Новый',
  in_progress: 'В работе',
  deal:        'Сделка',
  paid:        'Оплачен',
  closed:      'Закрыт',
};

const STATUS_COLORS: Record<Client['status'], string> = {
  new:         'bg-gray-100 text-gray-600',
  in_progress: 'bg-blue-100 text-blue-700',
  deal:        'bg-yellow-100 text-yellow-700',
  paid:        'bg-green-100 text-green-700',
  closed:      'bg-red-100 text-red-600',
};

const CONTACT_TYPE_LABELS: Record<Client['contact_type'], string> = {
  whatsapp: '📱 WhatsApp',
  call:     '📞 Звонок',
  visit:    '🚶 Визит',
};

export function ClientInfo({ client, onUpdate }: Props) {
  const [editMode, setEditMode] = useState(false);
  const [form, setForm] = useState({ name: client.name ?? '', email: client.email ?? '', notes: client.notes ?? '' });
  const [saving, setSaving] = useState(false);

  async function saveClient() {
    setSaving(true);
    try {
      const { error } = await supabase
        .from('clients')
        .update({
          name: form.name.trim() || null,
          email: form.email.trim() || null,
          notes: form.notes.trim() || null,
          updated_at: new Date().toISOString(),
        })
        .eq('id', client.id);
      if (error) throw error;
      onUpdate?.({ name: form.name, email: form.email, notes: form.notes });
      setEditMode(false);
    } catch (err) {
      console.error('ClientInfo save error:', err);
    } finally {
      setSaving(false);
    }
  }

  function formatDate(iso?: string) {
    if (!iso) return '—';
    return new Date(iso).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' });
  }

  return (
    <div className="p-4">
      <div className="flex items-center justify-between mb-3">
        <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Клиент</p>
        <button
          onClick={() => setEditMode(v => !v)}
          className="text-xs text-blue-600 hover:text-blue-800 font-medium"
        >
          {editMode ? 'Отмена' : 'Редактировать'}
        </button>
      </div>

      {editMode ? (
        <div className="space-y-2">
          <div>
            <label className="text-xs text-gray-400">Имя</label>
            <input
              type="text"
              value={form.name}
              onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
              className="w-full mt-0.5 text-sm border border-gray-200 rounded px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-blue-400"
              placeholder="Имя клиента"
            />
          </div>
          <div>
            <label className="text-xs text-gray-400">Email</label>
            <input
              type="email"
              value={form.email}
              onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
              className="w-full mt-0.5 text-sm border border-gray-200 rounded px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-blue-400"
              placeholder="email@example.com"
            />
          </div>
          <div>
            <label className="text-xs text-gray-400">Заметки о клиенте</label>
            <textarea
              rows={3}
              value={form.notes}
              onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
              className="w-full mt-0.5 text-sm border border-gray-200 rounded px-2 py-1.5 resize-none focus:outline-none focus:ring-1 focus:ring-blue-400"
              placeholder="Предпочтения, детали..."
            />
          </div>
          <button
            onClick={saveClient}
            disabled={saving}
            className="w-full text-xs bg-blue-600 text-white rounded py-1.5 hover:bg-blue-700 disabled:opacity-50 transition-colors"
          >
            {saving ? 'Сохранение...' : 'Сохранить'}
          </button>
        </div>
      ) : (
        <div className="space-y-2.5">
          {/* Аватар + имя */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white font-semibold text-base flex-shrink-0">
              {(client.name ?? client.phone)[0].toUpperCase()}
            </div>
            <div className="min-w-0">
              <p className="text-sm font-semibold text-gray-900 truncate">
                {client.name ?? 'Без имени'}
              </p>
              <p className="text-xs text-gray-500">{client.phone}</p>
            </div>
          </div>

          {/* Статус */}
          <div className="flex items-center gap-2">
            <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${STATUS_COLORS[client.status]}`}>
              {STATUS_LABELS[client.status]}
            </span>
            <span className="text-xs text-gray-400">
              {CONTACT_TYPE_LABELS[client.contact_type]}
            </span>
          </div>

          {/* Email */}
          {client.email && (
            <div>
              <p className="text-[10px] text-gray-400 uppercase tracking-wide">Email</p>
              <p className="text-sm text-gray-700">{client.email}</p>
            </div>
          )}

          {/* Даты */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <p className="text-[10px] text-gray-400 uppercase tracking-wide">Первый контакт</p>
              <p className="text-xs text-gray-700">{formatDate(client.first_contact_date)}</p>
            </div>
            <div>
              <p className="text-[10px] text-gray-400 uppercase tracking-wide">Последний</p>
              <p className="text-xs text-gray-700">{formatDate(client.last_contact_date)}</p>
            </div>
          </div>

          {/* Заметки */}
          {client.notes && (
            <div>
              <p className="text-[10px] text-gray-400 uppercase tracking-wide mb-1">Заметки</p>
              <p className="text-xs text-gray-700 bg-gray-50 rounded px-2 py-1.5 whitespace-pre-wrap">{client.notes}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

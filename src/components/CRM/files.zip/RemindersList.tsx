import { useEffect, useState } from 'react';
import { supabase } from '@/services/supabase';
import { useAuth } from '@/hooks/useAuth';
import type { Reminder } from '@/types';

interface Props {
  chatId: string;
}

export function RemindersList({ chatId }: Props) {
  const { employee } = useAuth();
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ text: '', remind_at: '' });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchReminders();
  }, [chatId]);

  async function fetchReminders() {
    setLoading(true);
    const { data, error } = await supabase
      .from('reminders')
      .select('*')
      .eq('chat_id', chatId)
      .eq('is_sent', false)
      .gte('remind_at', new Date().toISOString())
      .order('remind_at', { ascending: true });
    if (!error) setReminders(data ?? []);
    setLoading(false);
  }

  async function createReminder() {
    if (!employee || !form.text.trim() || !form.remind_at) return;
    setSaving(true);
    try {
      const { error } = await supabase.from('reminders').insert({
        chat_id: chatId,
        employee_id: employee.id,
        text: form.text.trim(),
        remind_at: new Date(form.remind_at).toISOString(),
      });
      if (error) throw error;
      setForm({ text: '', remind_at: '' });
      setShowForm(false);
      await fetchReminders();
    } catch (err) {
      console.error('Reminder create error:', err);
    } finally {
      setSaving(false);
    }
  }

  async function deleteReminder(id: string) {
    await supabase.from('reminders').delete().eq('id', id);
    setReminders(prev => prev.filter(r => r.id !== id));
  }

  function formatDate(iso: string) {
    return new Date(iso).toLocaleDateString('ru-RU', {
      day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit',
    });
  }

  function isOverdue(iso: string) {
    return new Date(iso) < new Date();
  }

  return (
    <div className="p-4 border-b border-gray-100">
      <div className="flex items-center justify-between mb-3">
        <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide">
          Напоминания {reminders.length > 0 && <span className="ml-1 text-orange-500">{reminders.length}</span>}
        </p>
        <button
          onClick={() => setShowForm(v => !v)}
          className="text-xs text-blue-600 hover:text-blue-800 font-medium"
        >
          {showForm ? 'Отмена' : '+ Добавить'}
        </button>
      </div>

      {showForm && (
        <div className="mb-3 space-y-2 bg-gray-50 rounded-lg p-3">
          <input
            type="text"
            placeholder="Текст напоминания"
            value={form.text}
            onChange={e => setForm(f => ({ ...f, text: e.target.value }))}
            className="w-full text-sm border border-gray-200 rounded px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-blue-400"
          />
          <input
            type="datetime-local"
            value={form.remind_at}
            onChange={e => setForm(f => ({ ...f, remind_at: e.target.value }))}
            className="w-full text-xs border border-gray-200 rounded px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-blue-400"
          />
          <button
            onClick={createReminder}
            disabled={saving || !form.text.trim() || !form.remind_at}
            className="w-full text-xs bg-orange-500 text-white rounded py-1.5 hover:bg-orange-600 disabled:opacity-50 transition-colors"
          >
            {saving ? 'Сохранение...' : 'Создать напоминание'}
          </button>
        </div>
      )}

      {loading ? (
        <p className="text-xs text-gray-400">Загрузка...</p>
      ) : reminders.length === 0 ? (
        <p className="text-xs text-gray-400">Нет предстоящих напоминаний</p>
      ) : (
        <ul className="space-y-2">
          {reminders.map(r => (
            <li key={r.id} className="flex items-start gap-2 group">
              <span className="mt-0.5 text-base leading-none">🔔</span>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-gray-800 leading-tight">{r.text}</p>
                <p className={`text-[10px] mt-0.5 ${isOverdue(r.remind_at) ? 'text-red-500 font-semibold' : 'text-gray-400'}`}>
                  {isOverdue(r.remind_at) ? '⚠ ' : ''}{formatDate(r.remind_at)}
                </p>
              </div>
              <button
                onClick={() => deleteReminder(r.id)}
                className="opacity-0 group-hover:opacity-100 text-gray-300 hover:text-red-400 text-xs transition-all"
              >
                ✕
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

import { useEffect, useState } from 'react';
import { supabase } from '@/services/supabase';
import { useAuth } from '@/hooks/useAuth';
import type { Task } from '@/types';

interface Props {
  chatId: string;
}

type Priority = Task['priority'];

const PRIORITY_COLORS: Record<Priority, string> = {
  low:    'bg-gray-200 text-gray-600',
  normal: 'bg-blue-100 text-blue-700',
  high:   'bg-red-100 text-red-600',
};

const PRIORITY_LABELS: Record<Priority, string> = {
  low: 'Низкий', normal: 'Средний', high: 'Высокий',
};

export function TasksList({ chatId }: Props) {
  const { employee } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ title: '', priority: 'normal' as Priority, due_date: '' });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchTasks();
  }, [chatId]);

  async function fetchTasks() {
    setLoading(true);
    const { data, error } = await supabase
      .from('tasks')
      .select('*')
      .eq('chat_id', chatId)
      .eq('status', 'open')
      .order('due_date', { ascending: true, nullsFirst: false });
    if (!error) setTasks(data ?? []);
    setLoading(false);
  }

  async function createTask() {
    if (!employee || !form.title.trim()) return;
    setSaving(true);
    try {
      const { error } = await supabase.from('tasks').insert({
        chat_id: chatId,
        employee_id: employee.id,
        title: form.title.trim(),
        priority: form.priority,
        due_date: form.due_date || null,
        status: 'open',
      });
      if (error) throw error;
      setForm({ title: '', priority: 'normal', due_date: '' });
      setShowForm(false);
      await fetchTasks();
    } catch (err) {
      console.error('Task create error:', err);
    } finally {
      setSaving(false);
    }
  }

  async function completeTask(id: string) {
    await supabase
      .from('tasks')
      .update({ status: 'completed', completed_at: new Date().toISOString() })
      .eq('id', id);
    setTasks(prev => prev.filter(t => t.id !== id));
  }

  return (
    <div className="p-4 border-b border-gray-100">
      <div className="flex items-center justify-between mb-3">
        <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide">
          Задачи {tasks.length > 0 && <span className="ml-1 text-blue-600">{tasks.length}</span>}
        </p>
        <button
          onClick={() => setShowForm(v => !v)}
          className="text-xs text-blue-600 hover:text-blue-800 font-medium"
        >
          {showForm ? 'Отмена' : '+ Добавить'}
        </button>
      </div>

      {showForm && (
        <div className="mb-3 space-y-2 bg-gray-50 rounded-lg p-3">
          <input
            type="text"
            placeholder="Название задачи"
            value={form.title}
            onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
            className="w-full text-sm border border-gray-200 rounded px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-blue-400"
          />
          <div className="flex gap-2">
            <select
              value={form.priority}
              onChange={e => setForm(f => ({ ...f, priority: e.target.value as Priority }))}
              className="text-xs border border-gray-200 rounded px-2 py-1.5 flex-1 focus:outline-none focus:ring-1 focus:ring-blue-400"
            >
              <option value="low">Низкий</option>
              <option value="normal">Средний</option>
              <option value="high">Высокий</option>
            </select>
            <input
              type="datetime-local"
              value={form.due_date}
              onChange={e => setForm(f => ({ ...f, due_date: e.target.value }))}
              className="text-xs border border-gray-200 rounded px-2 py-1.5 flex-1 focus:outline-none focus:ring-1 focus:ring-blue-400"
            />
          </div>
          <button
            onClick={createTask}
            disabled={saving || !form.title.trim()}
            className="w-full text-xs bg-blue-600 text-white rounded py-1.5 hover:bg-blue-700 disabled:opacity-50 transition-colors"
          >
            {saving ? 'Сохранение...' : 'Создать задачу'}
          </button>
        </div>
      )}

      {loading ? (
        <p className="text-xs text-gray-400">Загрузка...</p>
      ) : tasks.length === 0 ? (
        <p className="text-xs text-gray-400">Нет открытых задач</p>
      ) : (
        <ul className="space-y-2">
          {tasks.map(task => (
            <li key={task.id} className="flex items-start gap-2 group">
              <button
                onClick={() => completeTask(task.id)}
                className="mt-0.5 w-4 h-4 rounded border border-gray-300 hover:border-green-500 hover:bg-green-50 transition-colors flex-shrink-0"
              />
              <div className="flex-1 min-w-0">
                <p className="text-sm text-gray-800 leading-tight">{task.title}</p>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${PRIORITY_COLORS[task.priority]}`}>
                    {PRIORITY_LABELS[task.priority]}
                  </span>
                  {task.due_date && (
                    <span className="text-[10px] text-gray-400">
                      {new Date(task.due_date).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                    </span>
                  )}
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

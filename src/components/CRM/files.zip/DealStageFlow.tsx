import { useState } from 'react';
import { supabase } from '@/services/supabase';
import { useAuth } from '@/hooks/useAuth';
import type { DealStage } from '@/types';

const STAGES: { key: DealStage['current_stage']; label: string; color: string }[] = [
  { key: 'new',         label: 'Новый',      color: 'bg-gray-400' },
  { key: 'negotiation', label: 'Переговоры', color: 'bg-blue-500' },
  { key: 'quote',       label: 'Счёт',       color: 'bg-yellow-500' },
  { key: 'payment',     label: 'Оплата',     color: 'bg-orange-500' },
  { key: 'closed',      label: 'Закрыт',     color: 'bg-green-600' },
];

interface Props {
  chatId: string;
  currentStage: DealStage['current_stage'];
  onStageChange?: (stage: DealStage['current_stage']) => void;
}

export function DealStageFlow({ chatId, currentStage, onStageChange }: Props) {
  const { employee } = useAuth();
  const [loading, setLoading] = useState(false);

  const currentIdx = STAGES.findIndex(s => s.key === currentStage);

  async function moveToStage(stage: DealStage['current_stage']) {
    if (!employee || stage === currentStage || loading) return;
    setLoading(true);
    try {
      const { error } = await supabase.from('deal_stages').insert({
        chat_id: chatId,
        current_stage: stage,
        moved_to_stage_at: new Date().toISOString(),
        moved_by_id: employee.id,
      });
      if (error) throw error;
      onStageChange?.(stage);
    } catch (err) {
      console.error('DealStageFlow error:', err);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="p-4 border-b border-gray-100">
      <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-3">Этап сделки</p>
      <div className="flex items-center gap-1">
        {STAGES.map((s, idx) => {
          const isActive = s.key === currentStage;
          const isPast = idx < currentIdx;
          return (
            <button
              key={s.key}
              onClick={() => moveToStage(s.key)}
              disabled={loading}
              title={s.label}
              className={`
                flex-1 h-2 rounded-full transition-all duration-200 cursor-pointer
                ${isActive ? s.color : isPast ? 'bg-gray-300' : 'bg-gray-100'}
                ${!isActive ? 'hover:opacity-70' : ''}
              `}
            />
          );
        })}
      </div>
      <div className="flex justify-between mt-1">
        {STAGES.map((s, idx) => (
          <button
            key={s.key}
            onClick={() => moveToStage(s.key)}
            disabled={loading}
            className={`
              text-[10px] transition-colors duration-200
              ${s.key === currentStage ? 'font-semibold text-gray-800' : 'text-gray-400 hover:text-gray-600'}
            `}
          >
            {s.label}
          </button>
        ))}
      </div>
    </div>
  );
}

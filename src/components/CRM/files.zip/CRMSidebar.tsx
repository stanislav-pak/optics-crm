import { useEffect, useState } from 'react';
import { supabase } from '@/services/supabase';
import type { Chat, Client, DealStage } from '@/types';
import { DealStageFlow } from './DealStageFlow';
import { TasksList } from './TasksList';
import { RemindersList } from './RemindersList';
import { CommentsList } from './CommentsList';
import { ClientInfo } from './ClientInfo';

interface Props {
  chat: Chat;
}

export function CRMSidebar({ chat }: Props) {
  const [client, setClient] = useState<Client | null>(chat.client ?? null);
  const [currentStage, setCurrentStage] = useState<DealStage['current_stage']>('new');
  const [loadingStage, setLoadingStage] = useState(true);

  useEffect(() => {
    if (!chat.client) fetchClient();
    else setClient(chat.client);
    fetchLastStage();
  }, [chat.id]);

  async function fetchClient() {
    const { data } = await supabase
      .from('clients')
      .select('*')
      .eq('id', chat.client_id)
      .single();
    if (data) setClient(data);
  }

  async function fetchLastStage() {
    setLoadingStage(true);
    const { data } = await supabase
      .from('deal_stages')
      .select('current_stage')
      .eq('chat_id', chat.id)
      .order('moved_to_stage_at', { ascending: false })
      .limit(1)
      .maybeSingle();
    setCurrentStage(data?.current_stage ?? 'new');
    setLoadingStage(false);
  }

  return (
    <aside className="w-72 flex-shrink-0 border-l border-gray-200 bg-white flex flex-col overflow-y-auto">
      {/* Этапы сделки */}
      {!loadingStage && (
        <DealStageFlow
          chatId={chat.id}
          currentStage={currentStage}
          onStageChange={setCurrentStage}
        />
      )}

      {/* Задачи */}
      <TasksList chatId={chat.id} />

      {/* Напоминания */}
      <RemindersList chatId={chat.id} />

      {/* Комментарии / заметки */}
      <CommentsList chatId={chat.id} />

      {/* Информация о клиенте */}
      {client && (
        <ClientInfo
          client={client}
          onUpdate={updated => setClient(prev => prev ? { ...prev, ...updated } : prev)}
        />
      )}
    </aside>
  );
}
